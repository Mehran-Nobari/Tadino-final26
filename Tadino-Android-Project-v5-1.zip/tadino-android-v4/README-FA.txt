اپ اندروید Tadino (WebView) - نسخه 7.2
=========================================
سازگار با: Gradle 8.12 ، JDK 21 ، AGP 8.7.3 ، compileSdk/targetSdk 34 ، minSdk 21

اجرا در Android Studio:
1) File > Open > پوشه‌ی tadino-android را انتخاب کنید.
2) File > Settings > Build Tools > Gradle:
   - Use Gradle from: 'gradle-wrapper.properties' file  (نسخه 8.12 دانلود می‌شود)
     یا اگر Gradle 8.12.0 را از قبل دارید: 'Specified location' و مسیر آن را بدهید.
   - Gradle JDK: JDK 21 (یا jbr-21)
3) صبر کنید Sync تمام شود، سپس گوشی/امولاتور را انتخاب و Run را بزنید.
4) ساخت APK: Build > Build Bundle(s) / APK(s) > Build APK(s)
   خروجی: app/build/outputs/apk/debug/app-debug.apk
5) بار اول آدرس سرور را وارد کنید، مثل 192.168.1.5:3000
   تغییر آدرس: دکمه‌ی Back در صفحه‌ی اصلی > تغییر آدرس سرور.

تغییرات نسبت به نسخه‌ی قبل:
- AGP به 8.7.3 و Gradle به 8.12 ارتقا یافت (سازگار با JDK 21)
- minSdk=21 (اندروید 5)، compileSdk/targetSdk=34
- Java 17 به جای 8 (هشدار JDK 21 رفع شد)
- تم Material برای API 21 و بالاتر
- دکمه‌ی Back ابتدا در تاریخچه‌ی صفحه عقب می‌رود، و در صفحه‌ی اول منو نشان می‌دهد
- مدیریت خطای اتصال در همه‌ی نسخه‌های اندروید یکسان شد
- مجوز غیرضروری ACCESS_NETWORK_STATE حذف شد

تغییرات نسخه‌ی 7.2:
- بررسی مداوم اتصال: اگر وای‌فای یا ارتباط با سرور قطع شود، صفحه‌ی خطا نمایش داده می‌شود و برنامه تا برقراری دوباره‌ی اتصال قفل می‌ماند
- با برگشتن اتصال، خطا خودکار بسته می‌شود و برنامه ادامه می‌دهد (بدون نیاز به لمس دکمه)
- مجوز ACCESS_NETWORK_STATE برای تشخیص قطع بودن وای‌فای اضافه شد

ساخت APK بدون Android Studio (با GitHub Actions):
1) در GitHub یک Repository بسازید و تمام محتویات این پوشه (از جمله پوشه‌ی .github) را آپلود کنید
2) تب Actions > Build APK > منتظر تمام شدن (حدود ۳ تا ۶ دقیقه)
3) در پایین صفحه‌ی همان اجرا، بخش Artifacts > فایل Tadino-APK را دانلود کنید (زیپ است، داخلش app-debug.apk)
