package ir.tadino.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.WindowManager;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final int FILE_REQ = 11;
    private WebView web;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCb;
    private boolean errShown = false;
    private AlertDialog errDlg;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("tadino", MODE_PRIVATE);

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        web.setWebViewClient(new WebViewClient() {
            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView v, int code, String desc, String url) {
                // Called for main-frame errors on all API levels (21+)
                if (url != null && url.equals(v.getUrl()) || v.getUrl() == null) showError();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("باشه", (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("تایید", (d, w) -> r.confirm())
                        .setNegativeButton("انصراف", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView v, String url, String msg, String def, final JsPromptResult r) {
                final EditText et = new EditText(MainActivity.this);
                et.setText(def == null ? "" : def);
                et.selectAll();
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setView(et)
                        .setPositiveButton("تایید", (d, w) -> r.confirm(et.getText().toString()))
                        .setNegativeButton("انصراف", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        String saved = prefs.getString("url", null);
        if (saved == null) askAddress(); else web.loadUrl(saved);
    }

    // Persian/Arabic digits -> ASCII, add http:// and default port 3000
    private static String normalize(String in) {
        String s = in.trim().replaceAll("\\s", "");
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c >= '\u06F0' && c <= '\u06F9') c = (char) ('0' + (c - '\u06F0'));
            else if (c >= '\u0660' && c <= '\u0669') c = (char) ('0' + (c - '\u0660'));
            sb.append(c);
        }
        s = sb.toString();
        if (s.isEmpty()) return null;
        String scheme = "http://";
        if (s.startsWith("https://")) { scheme = "https://"; s = s.substring(8); }
        else if (s.startsWith("http://")) s = s.substring(7);
        int slash = s.indexOf('/');
        if (slash >= 0) s = s.substring(0, slash);
        if (s.isEmpty()) return null;
        if (!s.contains(":") && scheme.equals("http://")) s = s + ":3000";
        return scheme + s + "/";
    }

    private void askAddress() {
        final String saved = prefs.getString("url", null);
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        et.setHint("192.168.1.5:3000");
        if (saved != null) et.setText(saved.replace("http://", "").replace("/", ""));
        AlertDialog.Builder d = new AlertDialog.Builder(this)
                .setTitle("آدرس سرور Tadino")
                .setMessage("آدرسی که در برنامه‌ی کامپیوتر (منوی Tadino > آدرس اتصال) نشان داده می‌شود را بنویسید.")
                .setView(et)
                .setCancelable(saved != null)
                .setPositiveButton("اتصال", (dlg, w) -> {
                    String u = normalize(et.getText().toString());
                    if (u == null) { askAddress(); return; }
                    prefs.edit().putString("url", u).apply();
                    web.loadUrl(u);
                });
        if (saved != null) d.setNegativeButton("انصراف", null);
        else d.setNegativeButton("خروج", (dlg, w) -> finish());
        d.show();
    }

    @SuppressWarnings("deprecation")
    private boolean networkUp() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo n = cm.getActiveNetworkInfo();
            return n != null && n.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    private String errText() {
        return networkUp()
                ? "ارتباط با سرور Tadino برقرار نیست. مطمئن شوید برنامه‌ی Tadino روی کامپیوتر باز است و این دستگاه به همان وای‌فای وصل است.\n\nاتصال به‌طور خودکار بررسی می‌شود..."
                : "این دستگاه به وای‌فای یا شبکه وصل نیست. لطفاً به وای‌فای وصل شوید.\n\nاتصال به‌طور خودکار بررسی می‌شود...";
    }

    // Checks the server in the background every 1.5s while the error dialog is open;
    // when the server becomes reachable the dialog closes and the page reloads by itself.
    private final Runnable probe = new Runnable() {
        @Override public void run() {
            if (!errShown) return;
            final String base = prefs.getString("url", null);
            new Thread(() -> {
                boolean ok = false;
                if (base != null) {
                    try {
                        HttpURLConnection c = (HttpURLConnection) new URL(base + "api/rev").openConnection();
                        c.setConnectTimeout(2500);
                        c.setReadTimeout(2500);
                        c.setUseCaches(false);
                        ok = c.getResponseCode() == 200;
                        c.disconnect();
                    } catch (Exception e) { ok = false; }
                }
                final boolean up = ok;
                runOnUiThread(() -> {
                    if (!errShown) return;
                    if (up) {
                        errShown = false;
                        if (errDlg != null) errDlg.dismiss();
                        web.reload();
                    } else {
                        if (errDlg != null) errDlg.setMessage(errText());
                        handler.postDelayed(probe, 1500);
                    }
                });
            }).start();
        }
    };

    private void showError() {
        if (errShown) return;
        errShown = true;
        errDlg = new AlertDialog.Builder(this)
                .setTitle("اتصال برقرار نیست")
                .setMessage(errText())
                .setCancelable(false)
                .setPositiveButton("بررسی فوری", (d, w) -> { errShown = false; web.reload(); })
                .setNeutralButton("تغییر آدرس", (d, w) -> { errShown = false; askAddress(); })
                .setNegativeButton("خروج", (d, w) -> finish())
                .create();
        errDlg.show();
        handler.removeCallbacks(probe);
        handler.postDelayed(probe, 1500);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (web.canGoBack()) { web.goBack(); return; }
        new AlertDialog.Builder(this)
                .setItems(new String[]{"ادامه", "بارگذاری مجدد", "تغییر آدرس سرور", "خروج"}, (d, i) -> {
                    if (i == 1) web.reload();
                    else if (i == 2) askAddress();
                    else if (i == 3) finish();
                }).show();
    }

    @SuppressWarnings("deprecation")
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ) {
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                fileCb = null;
            }
        } else super.onActivityResult(req, res, data);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(probe);
        super.onDestroy();
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
}
